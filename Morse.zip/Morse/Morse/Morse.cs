﻿using System;

namespace Morse
{
    class Morse

    {

        //define function

        static void Main(string[] args)

        {


            Code testCode = new Code();
            testCode.ReadFile();
            testCode.GetString();

            Console.ReadLine();

        }

    }
}
