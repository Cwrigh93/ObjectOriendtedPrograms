﻿using System;

using System.IO;

using System.Collections;

using System.Linq;

namespace Morse
{
    class Code

    {
        static ArrayList list1;
        static ArrayList list2;

        public void ReadFile()

        {

            string line;

            string sep = "\t";
            list1 = new ArrayList();
            list2 = new ArrayList();

            try

            {
                StreamReader reader = new StreamReader(@"C:\Users\blvck\source\repos\Morse\Morse\obj\Morse.txt");

                while ((line = reader.ReadLine()) != null)

                {
                     string[] wrd = line.Split(sep.ToCharArray());

                    list1.Add((char)wrd[0].ElementAt(0));

                    list2.Add(wrd[0]);
                }
                reader.Close();
            }

            catch (FileNotFoundException)
            {

            }
        }


        public void GetString()

        {
            while (true) {

                Console.WriteLine("Input the text you'd like to translate.");
                string userInput = Console.ReadLine();
                System.Threading.Thread.Sleep(2000);

                userInput = userInput.ToUpper();
                Console.WriteLine("You entered: "+ userInput);
                if (userInput == "0")
                    break;
                Trans(userInput);
            }
        }

        

        private static void Trans(string userInput)

        {
            System.Text.StringBuilder builder = new System.Text.StringBuilder();

            int var = 0;

            foreach (char character in userInput)

            {
                var = 0;
                if (character == ' ')

                {
                    var = 1;
                    builder.Append(" ");
                }

                else
                {
                    for (int i = 0; i < list1.Count; i++)
                    {
                        if ((char)list1[i] == character)
                        {
                            var = 1;
                            builder.Append(list2[i]);
                            builder.Append(" ");
                        }
                      
                    }
                    if (var != 1)

                    {

                        builder.Append(character);

                        builder.Append(" ");

                    }

                }
            }

            Console.WriteLine("Converted to: {0}", builder.ToString());
        }
    }


}
    
