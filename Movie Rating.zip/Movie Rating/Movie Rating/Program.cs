﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
//christopher wright////////
namespace Movie_Rating
{
    class Program
    {
        private static int userRating;
        private static int totalStars;
        private static int avgStars;
        private static int users;

        public static void nextUser() {
            users++;
            Console.WriteLine("Next user! Please rate our featured movie of the week");
            System.Threading.Thread.Sleep(1000);
            Console.WriteLine("Welcome! Enter a value between 1-4 to rate the movie");
            String userInput = Console.ReadLine();//takes user input for wager

            userRating = Convert.ToInt32(userInput);
            totalStars = totalStars + userRating;
            avgStars = totalStars / users;

            System.Threading.Thread.Sleep(1000);
            if (userRating == 1 || userRating == 2 || userRating == 3 || userRating == 4)
            {
                Console.WriteLine("You gave the movie " + userRating + " stars");
                nextUser();
            }
            else if (userRating > 4)
            {
                Console.WriteLine("Please enter a correct vaule from 1-4");
                threeChances();
            }
            else if(userRating <= 0) {
                Console.WriteLine("The average rating for the movie was: " + avgStars + " stars");
                Console.WriteLine("Number of raters was: "+users);
                System.Threading.Thread.Sleep(5000);
                System.Environment.Exit(0);
            }
            else
            {

                return;

            }
        }

        public static void threeChances()
        {
            int chances = 0;

            for (int i = 0; i < 3; i++)
            {
                System.Threading.Thread.Sleep(1000);
                Console.WriteLine("Please try again. Enter a rating, single value from 1-4.");
                 String userInput = Console.ReadLine();
                userRating = Convert.ToInt32(userInput);
                totalStars = totalStars + userRating;


                if (userRating == 1 || userRating == 2 || userRating == 3 || userRating == 4)
                {
                    Console.WriteLine("You gave the movie " + userRating + " stars");
                    System.Threading.Thread.Sleep(1000);
                    nextUser(); 
                }
                else  {

                    chances++;
                   
                }

            }

           
            while (chances == 3) {
                Console.WriteLine("Sorry. Next user up.");
                nextUser();
            }
           
        }
       
        static void Main(string[] args)
        {
            users = 0;
            totalStars=0;

            Console.WriteLine("Please rate our featured movie of the week");
            System.Threading.Thread.Sleep(1000);
            Console.WriteLine("Welcome! Enter a value between 1-4 to rate the movie");
            String userInput = Console.ReadLine();//takes user input for wager
            userRating = Convert.ToInt32(userInput);
            System.Threading.Thread.Sleep(1000);
            if (userRating==1|| userRating == 2|| userRating == 3|| userRating == 4)
            {
                totalStars = userRating;
                Console.WriteLine("You gave the movie " + userRating + " stars");
                nextUser();

            } else if(userRating > 4)
            {
                threeChances();
            }
            else
            {
                avgStars = totalStars / users-1;
                Console.WriteLine("The average rating for the movie was: "+ avgStars+" stars");
                System.Threading.Thread.Sleep(4000);
                System.Environment.Exit(0);
            }

        }
    }
}
