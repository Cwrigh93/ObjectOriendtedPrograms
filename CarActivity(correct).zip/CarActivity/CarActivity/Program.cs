﻿using System;

namespace CarActivity
{
    class Program
    {
        static void Main(string[] args)
        {
            Car fastCar = new Car(2018,"Corvette");
            int i;
            for (i = 1; i <= 5; i++)
            {
                fastCar.accelerate();
                Console.WriteLine( " current speed=" + fastCar.getSpeed());
                System.Threading.Thread.Sleep(1000);

            }
            Console.WriteLine("Braking has begun");
            for (i = 1; i <= 5; i++)
            {
                fastCar.brake();
                Console.WriteLine(" current speed=" + fastCar.getSpeed());
                System.Threading.Thread.Sleep(1000);
                if (i == 5)
                {
                    Console.WriteLine("Vehicle has stopped");
                }
            }
            System.Threading.Thread.Sleep(5000);

        }
    }
}
