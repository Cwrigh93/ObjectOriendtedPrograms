﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CarActivity
{
    public class Car
    {
        private int yearModel;
        private int speed;
        private string make;

       public Car(int year,string carMake) {
            year = yearModel;
            carMake = make;
            speed = 0;
        }
        public void setYear(int year) {
            year = yearModel;
        }
        public void setMake(string carMake)
        {
            carMake = make;
        }
        public void setSpeed(int s)
        {
            speed = s;
        }
        public int getYear()
        {
            return yearModel;
        }
        public String getMake()
        {
            return make;
        }
        public int getSpeed()
        {
            return speed;
        }
        public void accelerate()
        {
            speed += 5;
        }
        public void brake()
        {
            speed -= 5;
        }
    }
}
