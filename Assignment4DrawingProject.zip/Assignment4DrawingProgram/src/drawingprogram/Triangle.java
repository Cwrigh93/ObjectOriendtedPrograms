/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package drawingprogram;

import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.Polygon;

/**
 *
 * @author christopher wright
 */
public class Triangle extends Shape {

 
    private Color fillColor;
    int startX = getStartX();
    int startY = getStartY();
    int endX = getEndX();
    int endY = getEndY();
/**
 * 
 * @param startX
 * @param startY
 * @param endX
 * @param endY
 * @param lineColor
 * @param fillColor 
 */
    public Triangle(int startX, int startY, int endX, int endY, Color lineColor, Color fillColor) {
        super(startX, startY, endX, endY, lineColor);
        this.fillColor = fillColor;

    }
    private int[] xPoints = {startX,endX,startX+ (1/2* endX)};
    private int[] yPoints = {startY,endY,endY};
/**
 * 
 * @param g2d graphics to draw object
 */
    @Override
    public void draw(Graphics2D g2d) {
        // draw solid rectangle first
        g2d.setColor(fillColor);
        g2d.fillPolygon(xPoints, yPoints, 3);
        // draw outline rectangle on top
        g2d.setColor(getLineColor());
        g2d.drawPolygon(xPoints, yPoints, 3);
    }

    public static void draw(Graphics2D g2d, int x1, int y1, int x2, int y2, Color lc, Color fc) {
        // draw solid rectangle first
        g2d.setColor(fc);
        g2d.fillPolygon(new int[]{x1, x2, x1 + (1 / 2 * x2)}, new int[]{y1, y2, y2}, 3);

        // draw outline on top
        g2d.setColor(lc);
        g2d.drawPolygon(new int[]{x1, x2, x1 + (1 / 2 * x2)}, new int[]{y1, y2, y2}, 3);

    }
}
