/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package drawingprogram;

import java.awt.Color;
import java.awt.Graphics2D;

/**
 *
 * @author christopher wright
 */
public abstract class Shape {

    private int startX;
    private int startY;
    private int endX;
    private int endY;
    private Color lineColor;

    /**
     *
     * @param startX The top left X coordinate
     * @param startY The top left Y coordinate
     * @param width The width of the object
     * @param height The height of the object
     * @param color The outline color of the object
     */
    public Shape(int startX, int startY, int endX, int endY, Color lineColor) {
        this.startX = startX;
        this.startY = startY;
        this.endX = endX;
        this.endY = endY;
        this.lineColor = lineColor;
    }
/**
 * 
 * @param g2d graphics to draw
 */
    public void draw(Graphics2D g2d) {
        g2d.setColor(getLineColor());
        g2d.drawLine(getStartX(), getStartY(), getEndX(), getEndY());
    }
/**
 * 
 * @return returns starting X position
 */
    public int getStartX() {
        return startX;
    }
/**
 * 
 * @return  returns starting y position
 */
    public int getStartY() {
        return startY;
    }
/**
 * 
 * @return  returns ending X position
 */
    public int getEndX() {
        return endX;
    }
/**
 * 
 * @return  returns ending Y position
 */
    public int getEndY() {
        return endY;
    }
/**
 * 
 * @return line color
 */
    public Color getLineColor() {
        return lineColor;
    }

}
