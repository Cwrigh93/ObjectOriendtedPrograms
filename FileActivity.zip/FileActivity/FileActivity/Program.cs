﻿using System;
using static System.Console;
using System.IO;

namespace FileActivity
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] arr = { 0 };
            const string FILENAME = "Numbers.txt";
            const string OddNums = "OddNums.txt";
            const string EvenNums = "EvenNums.txt";

            FileStream infile = new FileStream(FILENAME, FileMode.Open, FileAccess.Read);
            FileStream outFileEven = new FileStream(EvenNums, FileMode.Create, FileAccess.Write);
            FileStream outFileOdd = new FileStream(OddNums, FileMode.Create, FileAccess.Write);

            StreamReader sr = new StreamReader(infile);
            StreamWriter Evens = new StreamWriter(outFileEven);
            StreamWriter Odds = new StreamWriter(outFileOdd);

            string str;
            int i = 0;
            while ((str = sr.ReadLine()) != null)
            {
                arr[i] = Convert.ToInt32(str);
                if (arr[i] % 2 == 0)
                {
                    Evens.WriteLine(arr[i]);
                    Console.WriteLine("Number is even: " + arr[i]);

                }
                else
                {
                    Odds.WriteLine(arr[i]);
                    Console.WriteLine("Number is odd: " + arr[i]);

                }
            }

            Evens.Close();
            Odds.Close();
            sr.Close();
            infile.Close();

            Console.WriteLine("Press any key to exit");
            Console.ReadKey();
        }


    }
}
