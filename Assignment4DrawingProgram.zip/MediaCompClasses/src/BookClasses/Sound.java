package BookClasses;

import java.util.Random;

/**
 * Class that represents a sound. This class is used by the students to extend
 * the capabilities of SimpleSound.
 *
 * Copyright Georgia Institute of Technology 2004
 *
 * @author Barbara Ericson ericson@cc.gatech.edu
 */
public class Sound extends SimpleSound {

    /////////////// consructors ////////////////////////////////////
    /**
     * Constructor that takes a file name
     *
     * @param fileName the name of the file to read the sound from
     */
    public Sound(String fileName) {
        // let the parent class handle setting the file name
        super(fileName);
    }

    /**
     * Constructor that takes the number of samples in the sound
     *
     * @param numSamples the number of samples desired
     */
    public Sound(int numSamples) {
        // let the parent class handle this
        super(numSamples);
    }

    /**
     * Constructor that takes the number of samples that this sound will have
     * and the sample rate
     *
     * @param numSamples the number of samples desired
     * @param sampleRate the number of samples per second
     */
    public Sound(int numSamples, int sampleRate) {
        // let the parent class handle this
        super(numSamples, sampleRate);
    }

    /**
     * Constructor that takes a sound to copy
     */
    public Sound(Sound copySound) {
        // let the parent class handle this
        super(copySound);
    }

    ////////////////// methods ////////////////////////////////////
    /**
     * Method to return the string representation of this sound
     *
     * @return a string with information about this sound
     */
    public String toString() {
        String output = "Sound";
        String fileName = getFileName();

        // if there is a file name then add that to the output
        if (fileName != null) {
            output = output + " file: " + fileName;
        }

        // add the length in frames
        output = output + " number of samples: " + getLengthInFrames();

        return output;
    }

    public static void main(String[] args) {
        Sound sound1 = new Sound(FileChooser.pickAFile());
        sound1.explore();
    }
    //program 65///////////////////////////////////////////////////////////////

    public void increaseVolume() {
        SoundSample[] sampleArray = this.getSamples();
        SoundSample sample = null;
        int value = 0;
        int index = 0;
        while (index < sampleArray.length) {
            sample = sampleArray[index];
            value = sample.getValue();
            sample.setValue(value * 2);
            index++;
        }
    }
    // program 68/////////////////////////////////////////////

    public void changeVolume(double factor) {
        SoundSample[] sampleArray = this.getSamples();
        SoundSample sample = null;
        int value = 0;
        for (SoundSample sampleArray1 : sampleArray) {
            sample = sampleArray1;
            value = sample.getValue();
            sample.setValue((int) (value * factor));
        }
    }

    public static int[] generateRandomUnique(int n) {
        Random random = new Random();
        int[] uniqueNum = new int[n];
        int[] checkNum = new int[n];
        int tempNum;
        boolean repeat = true;
        for (int i = 0; i < n; i++) {
            do {
                tempNum = random.nextInt(n);
                if (checkNum[tempNum] == 0) {
                    repeat = false;
                    uniqueNum[i] = tempNum;
                    checkNum[tempNum] = 1;
                }
            } while (repeat == true);
            repeat = true;
        }
        return uniqueNum;
    }
/////////////////Program 73 splice////////////////////////////////////////

    public void splice() {
        Sound sound1 = new Sound(FileChooser.getMediaPath("guzdial.wav"));
        Sound sound2 = new Sound(FileChooser.getMediaPath("is.wav"));
        int targetIndex = 0;
        int value = 0;

        for (int i = 0;
                i < sound1.getLength();
                i++, targetIndex++) {
            value = sound1.getSampleValueAt(i);
            this.setSampleValueAt(targetIndex, value);
        }
        for (int i = 0;
                i < (int) (this.getSamplingRate() * 0.1); i++, targetIndex++) {
            this.setSampleValueAt(targetIndex, value);
        }

    }
///////////////program 76///////////////////////////////////////////

    public void splice(Sound source,
            int sourceStart,
            int sourceStop,
            int targetStart) {
        for (int sourceIndex = sourceStart,
                targetIndex = targetStart;
                sourceIndex < sourceStop && targetIndex < this.getLength();
                sourceIndex++, targetIndex++) {
            this.setSampleValueAt(targetIndex, source.getSampleValueAt(sourceIndex));
        }
        {

        }
    }

    /////////program 78//////////////////////////////////////////
    public void reverse() {
        Sound orig = new Sound(this.getFileName());
        int length = this.getLength();

        for (int targetIndex = 0, sourceIndex = length - 1; targetIndex < length && sourceIndex > 0;
                targetIndex++, sourceIndex--) {
        }

    }

    ///////////////program 86///////////////////////////////////////
    public void changeFreq(double factor) {
        Sound s = new Sound(this.getFileName());
        for (double sourceIndex = 0, targetIndex = 0;
                targetIndex < this.getLength();
                sourceIndex = sourceIndex + factor, targetIndex++) {
            if (sourceIndex >= s.getLength()) {
                sourceIndex = 0;
            }
            this.setSampleValueAt((int) targetIndex, s.getSampleValueAt((int) sourceIndex));

        }
    }
    //////////////////////// program 88/////////////////////////////////////

    public static Sound createSineWave(int freq, int maxAmplitude) {
        Sound s
                = new Sound(FileChooser.getMediaPath("sec1silence.wav"));
        double samplingRate = s.getSamplingRate();
        double rawValue = 0;
        int value = 0;
        double interval = 1.0 / freq;
        double samplesPerCycle = interval * samplingRate;
        double maxValue = 2 * Math.PI;

        for (int i = 0; i < s.getLength(); i++) {
            rawValue = Math.sin((i / samplesPerCycle) * maxValue);
            value = (int) (maxAmplitude * rawValue);
            s.setSampleValueAt(i, value);
        }
        return s;
    }
////////////////program 102///////////////////////////////////
}
