﻿namespace CateringForm
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.nameBox = new System.Windows.Forms.TextBox();
            this.numBox = new System.Windows.Forms.TextBox();
            this.numGuestBox = new System.Windows.Forms.TextBox();
            this.chkEntree = new System.Windows.Forms.CheckedListBox();
            this.chkSides = new System.Windows.Forms.CheckedListBox();
            this.chkDesert = new System.Windows.Forms.CheckedListBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.priceBox = new System.Windows.Forms.TextBox();
            this.priceButton = new System.Windows.Forms.Button();
            this.submitButton = new System.Windows.Forms.Button();
            this.entreeLabel = new System.Windows.Forms.Label();
            this.sidelabel = new System.Windows.Forms.Label();
            this.desertLabel = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // nameBox
            // 
            this.nameBox.Location = new System.Drawing.Point(30, 105);
            this.nameBox.Name = "nameBox";
            this.nameBox.Size = new System.Drawing.Size(269, 20);
            this.nameBox.TabIndex = 0;
            this.nameBox.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // numBox
            // 
            this.numBox.Location = new System.Drawing.Point(30, 159);
            this.numBox.Name = "numBox";
            this.numBox.Size = new System.Drawing.Size(269, 20);
            this.numBox.TabIndex = 1;
            this.numBox.TextChanged += new System.EventHandler(this.textBox2_TextChanged);
            // 
            // numGuestBox
            // 
            this.numGuestBox.Location = new System.Drawing.Point(30, 227);
            this.numGuestBox.Name = "numGuestBox";
            this.numGuestBox.Size = new System.Drawing.Size(79, 20);
            this.numGuestBox.TabIndex = 2;
            this.numGuestBox.TextChanged += new System.EventHandler(this.textBox3_TextChanged);
            // 
            // chkEntree
            // 
            this.chkEntree.CheckOnClick = true;
            this.chkEntree.FormattingEnabled = true;
            this.chkEntree.Items.AddRange(new object[] {
            "Chicken",
            "Beef",
            "Pork",
            "Salad"});
            this.chkEntree.Location = new System.Drawing.Point(356, 89);
            this.chkEntree.Name = "chkEntree";
            this.chkEntree.Size = new System.Drawing.Size(131, 64);
            this.chkEntree.TabIndex = 3;
            this.chkEntree.SelectedIndexChanged += new System.EventHandler(this.checkedListBox1_SelectedIndexChanged);
            // 
            // chkSides
            // 
            this.chkSides.CheckOnClick = true;
            this.chkSides.FormattingEnabled = true;
            this.chkSides.Items.AddRange(new object[] {
            "Soup",
            "Salad",
            "Breadsticks",
            "Rolls"});
            this.chkSides.Location = new System.Drawing.Point(356, 175);
            this.chkSides.Name = "chkSides";
            this.chkSides.Size = new System.Drawing.Size(131, 64);
            this.chkSides.TabIndex = 4;
            this.chkSides.SelectedIndexChanged += new System.EventHandler(this.checkedListBox2_SelectedIndexChanged);
            // 
            // chkDesert
            // 
            this.chkDesert.CheckOnClick = true;
            this.chkDesert.FormattingEnabled = true;
            this.chkDesert.Items.AddRange(new object[] {
            "Apple Pie",
            "Red Velvet Cake",
            "Vanilla Milkshake"});
            this.chkDesert.Location = new System.Drawing.Point(356, 263);
            this.chkDesert.Name = "chkDesert";
            this.chkDesert.Size = new System.Drawing.Size(131, 79);
            this.chkDesert.TabIndex = 5;
            this.chkDesert.SelectedIndexChanged += new System.EventHandler(this.chkDesert_SelectedIndexChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(27, 89);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(82, 13);
            this.label1.TabIndex = 6;
            this.label1.Text = "Customer Name";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(27, 143);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(91, 13);
            this.label2.TabIndex = 7;
            this.label2.Text = "Customer Number";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(27, 210);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(87, 13);
            this.label3.TabIndex = 8;
            this.label3.Text = "Number of Guest";
            this.label3.Click += new System.EventHandler(this.label3_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 25F);
            this.label4.Location = new System.Drawing.Point(23, 9);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(266, 39);
            this.label4.TabIndex = 9;
            this.label4.Text = "Cindy\'s Catering";
            this.label4.Click += new System.EventHandler(this.label4_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(27, 57);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(136, 13);
            this.label5.TabIndex = 10;
            this.label5.Text = "(The price per guest is $35)";
            this.label5.Click += new System.EventHandler(this.label5_Click_1);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(27, 272);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(57, 13);
            this.label6.TabIndex = 11;
            this.label6.Text = "Total price";
            // 
            // priceBox
            // 
            this.priceBox.Location = new System.Drawing.Point(30, 288);
            this.priceBox.Name = "priceBox";
            this.priceBox.Size = new System.Drawing.Size(79, 20);
            this.priceBox.TabIndex = 12;
            // 
            // priceButton
            // 
            this.priceButton.Location = new System.Drawing.Point(139, 285);
            this.priceButton.Name = "priceButton";
            this.priceButton.Size = new System.Drawing.Size(75, 23);
            this.priceButton.TabIndex = 13;
            this.priceButton.Text = "Calculate Price";
            this.priceButton.UseVisualStyleBackColor = true;
            this.priceButton.Click += new System.EventHandler(this.priceButton_Click);
            // 
            // submitButton
            // 
            this.submitButton.Location = new System.Drawing.Point(372, 360);
            this.submitButton.Name = "submitButton";
            this.submitButton.Size = new System.Drawing.Size(82, 27);
            this.submitButton.TabIndex = 14;
            this.submitButton.Text = "Submit";
            this.submitButton.UseVisualStyleBackColor = true;
            this.submitButton.Click += new System.EventHandler(this.submitButton_Click);
            // 
            // entreeLabel
            // 
            this.entreeLabel.AutoSize = true;
            this.entreeLabel.Location = new System.Drawing.Point(369, 73);
            this.entreeLabel.Name = "entreeLabel";
            this.entreeLabel.Size = new System.Drawing.Size(92, 13);
            this.entreeLabel.TabIndex = 15;
            this.entreeLabel.Text = "Select one Entree";
            this.entreeLabel.Click += new System.EventHandler(this.label7_Click);
            // 
            // sidelabel
            // 
            this.sidelabel.AutoSize = true;
            this.sidelabel.Location = new System.Drawing.Point(369, 159);
            this.sidelabel.Name = "sidelabel";
            this.sidelabel.Size = new System.Drawing.Size(112, 13);
            this.sidelabel.TabIndex = 16;
            this.sidelabel.Text = "Select two side dishes";
            // 
            // desertLabel
            // 
            this.desertLabel.AutoSize = true;
            this.desertLabel.Location = new System.Drawing.Point(369, 247);
            this.desertLabel.Name = "desertLabel";
            this.desertLabel.Size = new System.Drawing.Size(90, 13);
            this.desertLabel.TabIndex = 17;
            this.desertLabel.Text = "Select one desert";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(608, 450);
            this.Controls.Add(this.desertLabel);
            this.Controls.Add(this.sidelabel);
            this.Controls.Add(this.entreeLabel);
            this.Controls.Add(this.submitButton);
            this.Controls.Add(this.priceButton);
            this.Controls.Add(this.priceBox);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.chkDesert);
            this.Controls.Add(this.chkSides);
            this.Controls.Add(this.chkEntree);
            this.Controls.Add(this.numGuestBox);
            this.Controls.Add(this.numBox);
            this.Controls.Add(this.nameBox);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox nameBox;
        private System.Windows.Forms.TextBox numBox;
        private System.Windows.Forms.TextBox numGuestBox;
        private System.Windows.Forms.CheckedListBox chkEntree;
        private System.Windows.Forms.CheckedListBox chkSides;
        private System.Windows.Forms.CheckedListBox chkDesert;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox priceBox;
        private System.Windows.Forms.Button priceButton;
        private System.Windows.Forms.Button submitButton;
        private System.Windows.Forms.Label entreeLabel;
        private System.Windows.Forms.Label sidelabel;
        private System.Windows.Forms.Label desertLabel;
    }
}

