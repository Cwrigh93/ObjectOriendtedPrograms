﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CateringForm
{
    public partial class Form1 : Form
    {
       
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {
        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void checkedListBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
            ArrayList sides = new ArrayList();
                for (int i = chkSides.Items.Count - 1; i >= 0; i--)
                {
                    if (chkSides.GetItemCheckState(i) == CheckState.Checked)
                    {
                    sides.Add(i);
                    }
                }
                chkSides.Update();
            

        }

            private void checkedListBox1_SelectedIndexChanged(object sender, EventArgs e)
            {

                ArrayList entree = new ArrayList();
            string entreeChoice;
                if (chkEntree.CheckedItems.Count != 0)
                {
                    for (int x = 0; x < chkEntree.CheckedItems.Count; x++)
                    {
                        entree.Add(chkEntree.CheckedItems);
                    
                    }
                }
            }

            private void textBox1_TextChanged(object sender, EventArgs e)
            {
                string custName;
            }

            private void textBox3_TextChanged(object sender, EventArgs e)
            {
            
            }

            private void label5_Click(object sender, EventArgs e)
            {

            }

            private void label5_Click_1(object sender, EventArgs e)
            {

            }

            private void priceButton_Click(object sender, EventArgs e)
            {
                int price, numGuest;
            
                numGuest = Convert.ToInt32(numGuestBox.Text);
            if (numGuest is string)
            {
                numGuest = 0;
            }
            price = numGuest * 35;
                priceBox.Text = price.ToString("n");
            }

            private void submitButton_Click(object sender, EventArgs e)
            {
                string custName, custNum, price;
                int numGuest;
                numGuest = Convert.ToInt32(numGuestBox.Text);
                price = priceBox.Text;
                custName = nameBox.Text;
                custNum = numBox.Text;

            string entree = "";
            if (chkEntree.GetItemChecked(0) == true)
            {
                entree = "Chicken";

            }
            if (chkEntree.GetItemChecked(1) == true)
            {
                entree = "Beef";

            }
            if (chkEntree.GetItemChecked(2) == true)
            {
                entree = "Pork";

            }
            if (chkEntree.GetItemChecked(3) == true)
            {
                entree = "Salad";

            }

            string sides = "";
            if (chkSides.GetItemChecked(0) == true)
            {
                sides += "Soup";

            }
            if (chkSides.GetItemChecked(1) == true)
            {
                sides += "Salad";

            }
            if (chkSides.GetItemChecked(2) == true)
            {
                sides += "Breadsticks";

            }
            if (chkSides.GetItemChecked(3) == true)
            {
                sides += "Rolls";

            }

            string desert = "";
            if (chkDesert.GetItemChecked(0) == true)
            {
                desert = "Apple Pie";

            }
            if (chkDesert.GetItemChecked(1) == true)
            {
                desert = "Red Velvet Cake";

            }
            if (chkDesert.GetItemChecked(2) == true)
            {
                desert = "Vanilla Milkshake";

            }
            //////////////Write information to text file////////////////////////
            const string FILENAME = "Event.txt";
            FileStream outFile = new FileStream(FILENAME, FileMode.Create, FileAccess.Write);
            StreamWriter sr = new StreamWriter(outFile);
            sr.WriteLine("Customer Name: "+ custName);
            sr.WriteLine("Contact Number: "+ custNum);
            sr.WriteLine("Number of Guest: "+numGuest);
            sr.WriteLine("Price of event: "+ price);
            sr.WriteLine("Entree: " + entree);
            sr.WriteLine("Sides: " + sides);
            sr.WriteLine("Destert: " + desert);


            sr.Close();
            outFile.Close();
            Application.Exit();
        }

            private void chkDesert_SelectedIndexChanged(object sender, EventArgs e)
            {
                ArrayList desert = new ArrayList();
                if (chkDesert.CheckedItems.Count != 0)
                {
                    // If so, loop through all checked items and print results.  
                    for (int x = 0; x < chkDesert.CheckedItems.Count; x++)
                    {
                        desert.Add(chkDesert.CheckedItems);
                    }
                    string desertChoice = desert.ToString();
                }
            }

        private void label7_Click(object sender, EventArgs e)
        {

        }


        private void label7_Click_1(object sender, EventArgs e)
        {

        }

        private void custMeal_TextChanged(object sender, EventArgs e)
        {

        }
    }
    }
